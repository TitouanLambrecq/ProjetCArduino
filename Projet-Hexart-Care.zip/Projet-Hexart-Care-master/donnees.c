#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "action.h"
#include "donnees.h"

struct Personne pers_cardiaque;
//D�finition des fonctions de r�cup�ration des donn�es calcul�es
/*int getNbvaleur()
{
    return calcul_Nbvaleur();
}

int getPoulMax()
{
    return calcul_PoulMax();
}

int getPoulMin()
{
    return calcul_PoulMin();
}*/
