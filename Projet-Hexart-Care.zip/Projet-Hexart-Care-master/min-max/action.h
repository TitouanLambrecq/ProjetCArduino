#include <stdio.h>
#include <stdlib.h>

int valeurMin();
int valeurMax();
