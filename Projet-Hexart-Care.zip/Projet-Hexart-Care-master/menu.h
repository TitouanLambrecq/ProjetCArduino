#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//D�claration des fonction d'affichage des menus

void choisirMenu(void);

