//D�claration des fanctions de calculs des diff�rentes fr�quences cardiaques et de tri des valeurs

int calcul_moyennePoul();
int calcul_moyenneTemps();

int calcul_PoulMax();
int calcul_PoulMin();
int calcul_NbValeur();

int tri();

void read_file();
