#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "menu.h"

//Programme principal du projet qui va lancer l'application

int main()
{
    afficherMenu();
}
